import React from 'react'
import { motion } from 'framer-motion'

export default function App() {
  return (
    <div className="bg-black text-white min-h-screen">
      {/* Splash Logo */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
        className="flex items-center justify-center h-screen bg-black"
      >
        <h1 className="text-6xl md:text-8xl font-serif text-yellow-500">MANSA</h1>
      </motion.div>

      {/* Collection Section */}
      <section className="bg-black py-20 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-serif text-yellow-400">Collection</h2>
          <p className="text-yellow-200/70 mt-2 tracking-[0.25em] uppercase">Luxury Perfumes</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mt-12">
            <div className="relative overflow-hidden rounded-2xl border border-yellow-500/40">
              <img src="/images/perfume1.jpg" alt="MANSA Topaz Blue" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                <span className="text-yellow-400 text-2xl font-serif">MANSA Topaz Blue</span>
              </div>
            </div>
            <div className="relative overflow-hidden rounded-2xl border border-yellow-500/40">
              <img src="/images/perfume2.jpg" alt="MANSA Topaz Pink" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                <span className="text-yellow-400 text-2xl font-serif">MANSA Topaz Pink</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
